public class Wolf extends Piece {
    public Wolf(int x, int y, Player owner, Board board) {
        super("Wolf", x, y, owner, board);
    }

   
}