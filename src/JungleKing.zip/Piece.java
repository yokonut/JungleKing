public abstract class Piece {
    public String name;
    public int x, y;
    public Player owner;
    public Board board;

    public Piece(String name, int x, int y, Player owner, Board board) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.owner = owner;
        this.board = board;
    }

    // Move the piece to a new location
    public boolean move(int newX, int newY) {
        if (board.isNormal(newX, newY) || board.isOpponentHomeBase(newX, newY, owner)) {
            board.movePiece(this, newX, newY);
            return true;
        }
        return false;
    }

    public String getName() {
        return name;
    }

    public Player getOwner() {
        return owner;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}