public class Elephant extends Piece {
    public Elephant(int x, int y, Player owner, Board board) {
        super("Elephant", x, y, owner, board);
    }

    
}