public class Cat extends Piece {
    public Cat(int x, int y, Player owner, Board board) {
        super("Cat", x, y, owner, board);
    }

}