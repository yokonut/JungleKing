public class Leopard extends Piece {
    public Leopard(int x, int y, Player owner, Board board) {
        super("Leopard", x, y, owner, board);
    }

   
}