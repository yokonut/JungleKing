public class Dog extends Piece {
    public Dog(int x, int y, Player owner, Board board) {
        super("Dog", x, y, owner, board);
    }

   
}