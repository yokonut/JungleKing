public class Trap extends Tile {
    public Trap() {
        super("Trap");
    }

}
