public class Normal extends Tile {
    public Normal() {
        super("Normal");
    }
}
