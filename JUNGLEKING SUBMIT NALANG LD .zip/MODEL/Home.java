public class Home extends Tile {
    public Home() {
        super("Home");
    }
}
