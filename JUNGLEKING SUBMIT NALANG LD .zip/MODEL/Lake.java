public class Lake extends Tile {
    public Lake() {
        super("Lake");
    }
    
}
